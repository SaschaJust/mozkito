package de.unisaarland.cs.st.reposuite.genealogies.test.evironment;


public class C {
	
	public C() {
		B b = new B();
	}
	
}
