package de.unisaarland.cs.st.reposuite.genealogies.test.evironment;


public class D {
	
	public D() {
		float d = 0f;
	}
	
}
