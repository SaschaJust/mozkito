package de.unisaarland.cs.st.reposuite.genealogies.test.evironment;


public class B {
	
	public void bar(int y) {
		y += 1;
	}

}
