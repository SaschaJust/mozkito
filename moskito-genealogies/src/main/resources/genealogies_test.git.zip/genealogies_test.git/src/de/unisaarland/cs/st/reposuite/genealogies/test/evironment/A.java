package de.unisaarland.cs.st.reposuite.genealogies.test.evironment;


public class A {
	
}
