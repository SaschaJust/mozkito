/**
 * 
 */
package PPA;

import de.unisaarland.cs.st.reposuite.ppa.ReposuiteDeltaInfo;

/**
 * @author just
 * 
 */
public class Main {
	
	/**
	 * @param args
	 */
	public static void main(final String[] args) {
		ReposuiteDeltaInfo core = new ReposuiteDeltaInfo();
		core.run();
	}
}
