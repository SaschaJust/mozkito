/**
 * 
 */
package mapping;

import de.unisaarland.cs.st.reposuite.mapping.Mapping;

/**
 * @author just
 * 
 */
public class Main {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Mapping mapping = new Mapping(args);
		mapping.run();
	}
	
}
