package de.unisaarland.cs.st.reposuite.mapping;

public class Mapping extends Thread {
	
	public Mapping(String[] args) {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
