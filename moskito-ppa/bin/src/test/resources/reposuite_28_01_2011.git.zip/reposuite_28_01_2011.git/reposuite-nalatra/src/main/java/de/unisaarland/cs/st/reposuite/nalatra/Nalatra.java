package de.unisaarland.cs.st.reposuite.nalatra;

public class Nalatra extends Thread {
	
	public Nalatra(String[] args) {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
