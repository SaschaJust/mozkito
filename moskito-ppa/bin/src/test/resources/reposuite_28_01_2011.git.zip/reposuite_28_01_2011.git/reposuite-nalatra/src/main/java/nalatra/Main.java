/**
 * 
 */
package nalatra;

import de.unisaarland.cs.st.reposuite.nalatra.Nalatra;

/**
 * @author just
 * 
 */
public class Main {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Nalatra nalatra = new Nalatra(args);
		nalatra.run();
	}
	
}
