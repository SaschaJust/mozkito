package de.unisaarland.cs.st.reposuite.changecouplings;

/**
 * The Class ChangeCouplings.
 * 
 * @author Kim Herzig <herzig@cs.uni-saarland.de>
 */
public class ChangeCouplings extends Thread {
	
	/**
	 * Instantiates a new change couplings.
	 * 
	 * @param args
	 *            the args
	 */
	public ChangeCouplings(final String[] args) {
		// TODO Auto-generated constructor stub
	}
	
	/*
	 * (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
