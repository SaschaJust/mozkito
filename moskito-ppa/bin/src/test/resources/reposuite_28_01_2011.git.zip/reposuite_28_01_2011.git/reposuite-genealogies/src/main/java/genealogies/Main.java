/**
 * 
 */
package genealogies;

import de.unisaarland.cs.st.reposuite.genealogies.Genealogies;

/**
 * @author just
 * 
 */
public class Main {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Genealogies genealogies = new Genealogies(args);
		genealogies.run();
	}
	
}
