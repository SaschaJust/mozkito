package de.unisaarland.cs.st.reposuite.genealogies;

public class Genealogies extends Thread {
	
	public Genealogies(String[] args) {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
