/**
 * 
 */
package untangling;

import de.unisaarland.cs.st.reposuite.untangling.Untangling;

/**
 * @author just
 * 
 */
public class Main {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Untangling untangling = new Untangling(args);
		untangling.run();
	}
	
}
