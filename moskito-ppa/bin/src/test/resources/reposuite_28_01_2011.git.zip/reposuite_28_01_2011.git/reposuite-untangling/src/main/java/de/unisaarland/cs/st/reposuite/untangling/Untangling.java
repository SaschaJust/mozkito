package de.unisaarland.cs.st.reposuite.untangling;

public class Untangling extends Thread {
	
	public Untangling(String[] args) {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
