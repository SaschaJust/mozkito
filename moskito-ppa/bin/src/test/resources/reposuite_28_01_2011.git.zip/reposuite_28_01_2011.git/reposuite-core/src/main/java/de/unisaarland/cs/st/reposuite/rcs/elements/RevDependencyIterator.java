package de.unisaarland.cs.st.reposuite.rcs.elements;

import java.util.Iterator;

public interface RevDependencyIterator extends Iterator<RevDependency> {
	
	
	
}
