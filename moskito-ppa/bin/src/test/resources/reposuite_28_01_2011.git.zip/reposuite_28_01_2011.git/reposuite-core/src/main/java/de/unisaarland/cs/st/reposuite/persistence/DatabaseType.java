/**
 * 
 */
package de.unisaarland.cs.st.reposuite.persistence;


/**
 * @author Sascha Just <sascha.just@st.cs.uni-saarland.de>
 *
 */
public enum DatabaseType {
	POSTGRESQL, MYSQL;
}
