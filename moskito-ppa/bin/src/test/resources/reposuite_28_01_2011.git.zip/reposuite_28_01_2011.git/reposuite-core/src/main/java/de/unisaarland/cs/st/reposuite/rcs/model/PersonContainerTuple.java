package de.unisaarland.cs.st.reposuite.rcs.model;


public class PersonContainerTuple {
	
}
