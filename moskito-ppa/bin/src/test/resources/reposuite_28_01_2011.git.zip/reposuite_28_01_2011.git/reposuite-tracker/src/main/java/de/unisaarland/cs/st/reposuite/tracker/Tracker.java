package de.unisaarland.cs.st.reposuite.tracker;

public class Tracker extends Thread {
	
	public Tracker(String[] args) {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
