/**
 * 
 */
package tracker;

import de.unisaarland.cs.st.reposuite.tracker.Tracker;

/**
 * @author just
 * 
 */
public class Main {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Tracker tracker = new Tracker(args);
		tracker.run();
	}
	
}
