package de.unisaarland.cs.st.reposuite.fixindchanges;

public class FixInducingChanges extends Thread {
	
	public FixInducingChanges(String[] args) {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
	}
}
