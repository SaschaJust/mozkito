/**
 * 
 */
package de.unisaarland.cs.st.reposuite.bugs.tracker.issuezilla;

import de.unisaarland.cs.st.reposuite.bugs.tracker.RawReport;
import de.unisaarland.cs.st.reposuite.bugs.tracker.Tracker;
import de.unisaarland.cs.st.reposuite.bugs.tracker.XmlReport;
import de.unisaarland.cs.st.reposuite.bugs.tracker.model.Report;

/**
 * @author Sascha Just <sascha.just@st.cs.uni-saarland.de>
 * 
 */
public class IssuezillaTracker extends Tracker {
	
	@Override
	public XmlReport createDocument(final RawReport rawReport) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Report parse(final XmlReport rawReport) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
}
