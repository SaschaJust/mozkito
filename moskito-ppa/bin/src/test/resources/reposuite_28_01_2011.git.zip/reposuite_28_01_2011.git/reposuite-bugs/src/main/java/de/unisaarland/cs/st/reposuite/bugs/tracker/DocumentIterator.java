/**
 * 
 */
package de.unisaarland.cs.st.reposuite.bugs.tracker;


/**
 * @author Sascha Just <sascha.just@st.cs.uni-saarland.de>
 *
 */
public class DocumentIterator {
	
}
